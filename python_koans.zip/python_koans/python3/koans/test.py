# # i = 1
# # result = 1
# # while i <= 10:
# #     result = result * i
# #     i += 1
# #     print(result, i)

# i = 1
# result = 1
# while True:
#     if i > 10:
#         break
#     result = result * i
#     i += 1
#     print(result, i)

# i = 0
# result = []
# while i < 10:
#     i += 1
#     if (i % 2) == 0:
#         print('inner ', i)
#         continue
#     print(i)
#     result.append(i)

# round_table = [
#     ("Lancelot", "Blue"),
#     ("Galahad", "I don't know!"),
#     ("Robin", "Blue! I mean Green!"),
#     ("Arthur", "Is that an African Swallow or European Swallow?")
# ]
# result = []
# for knight, answer in round_table:
#     result.append("Contestant: '" + knight + "'   Answer: '" + answer + "'")
# print(result[2])

# def truth_value(condition):
#     if condition:
#         return 'true stuff'
#     else:
#         return 'false stuff'


# print(truth_value('0'))


# highlanders = ['MacLeod', 'Ramirez', 'MacLeod',
#                'Matunas', 'MacLeod', 'Malcolm', 'MacLeod']

# there_can_only_be_only_one = set(highlanders)
# print(there_can_only_be_only_one)

# print({1, 2, 3}.__class__)
# print({'one': 1, 'two': 2}.__class__)
# print({}.__class__)
# print(set('12345'))
# print(sorted(set('12345')))

scotsmen = {'MacLeod', 'Wallace', 'Willie'}
warriors = {'MacLeod', 'Wallace', 'Leonidas'}


# print(scotsmen - warriors)
# print(scotsmen | warriors)
# print(scotsmen & warriors)
# print(scotsmen ^ warriors)

# print(127 in {127, 0, 0, 1})

print(set('cake') <= set('cherry cake'))
