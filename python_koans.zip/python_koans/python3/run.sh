#!/bin/sh

python3 -B contemplate_koans.py

