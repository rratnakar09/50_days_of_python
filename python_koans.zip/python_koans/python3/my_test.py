def test():
    try:
        some_method_none_does_not_know_about()
    except Exception as ex:
        ex2 = ex
        print(ex2)


test()
